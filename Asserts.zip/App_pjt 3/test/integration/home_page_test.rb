# test/integration/home_page_test.rb

require "test_helper"

class HomePageTest < ActionDispatch::IntegrationTest
  include Devise::Test::IntegrationHelpers

  def setup
    @admin = users(:admin)
    @docente = users(:docente_1)
    @estudiante = users(:estudiante_1)
    @docentes = Docente.all
    @estudiantes = Estudiante.all
  end

  test "página de inicio muestra correctamente para administrador" do
    sign_in(@admin)
    get root_path
    assert_response :success
  end

  test "página de inicio muestra correctamente para docente" do
    sign_in(@docente)
    get root_path
    assert_response :success
  end

  test "página de inicio muestra correctamente para estudiante" do
    sign_in(@estudiante)
    get root_path
    assert_response :success

  end
end

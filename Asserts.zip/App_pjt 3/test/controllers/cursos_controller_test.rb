require "test_helper"

class CursosControllerTest < ActionDispatch::IntegrationTest
  include Devise::Test::IntegrationHelpers
  setup do
    @curso = cursos(:curso_1)
  end

  test "should get index" do
    get cursos_url
    assert_response :success
  end

  test "should get new" do
    get new_curso_url
    assert_response :success
  end

  test "should create curso" do
    assert_difference("Curso.count") do
      post cursos_url, params: { curso: { codigo_curso: @curso.codigo_curso, creditos: @curso.creditos, nombre: @curso.nombre } }
    end

    assert_redirected_to curso_url(Curso.last)
  end

  test "should show curso" do
    get curso_url(@curso)
    assert_response :success
  end

  test "should get edit" do
    get edit_curso_url(@curso)
    assert_response :success
  end

  test "should update curso" do
    patch curso_url(@curso), params: { curso: { codigo_curso: @curso.codigo_curso, creditos: @curso.creditos, nombre: @curso.nombre } }
    assert_redirected_to curso_url(@curso)
  end

  test "should destroy curso" do
    assert_difference("Curso.count", -1) do
      delete curso_url(@curso)
    end

    assert_redirected_to cursos_url
  end

  test 'should get inscripcion' do
    get inscripcion_cursos_path # Utiliza el método de ruta adecuado
    assert_response :success
    assert_not_nil assigns(:cursos)
  end

  test 'should enroll in courses' do
    user = users(:docente_1)
    sign_in user
    curso_ids = [@curso.id]
    post enroll_cursos_path, params: { curso_ids: curso_ids } # Utiliza el método de ruta adecuado
    assert_redirected_to inscripcion_cursos_path
    assert_equal 'Te has inscrito en los cursos exitosamente.', flash[:notice]
    assert_equal curso_ids, user.cursos.pluck(:id)
  end

end

require 'test_helper'

class InscripcionesControllerTest < ActionController::TestCase
  include Devise::Test::ControllerHelpers

  test 'should get cursos_inscritos' do
    user = users(:estudiante_1) # Suponiendo que tienes usuarios en tu archivo fixtures
    sign_in user

    get :cursos_inscritos
    assert_response :success

    assert_equal user, assigns(:user)
    assert_not_nil assigns(:cursos)
  end
end

require "test_helper"

class AdministradorsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @administrador = administradors(:one)
  end

  test "should get index" do
    get administradors_url
    assert_response :success
  end

  test "should get new" do
    get new_administrador_url
    assert_response :success
  end

  test "should create administrador" do
    assert_difference("Administrador.count") do
      post administradors_url, params: { administrador: { dni: @administrador.dni, numero_telefono: @administrador.numero_telefono, primer_apellido: @administrador.primer_apellido, primer_nombre: @administrador.primer_nombre, segundo_apellido: @administrador.segundo_apellido, segundo_nombre: @administrador.segundo_nombre } }
    end

    assert_redirected_to administrador_url(Administrador.last)
  end

  test "should show administrador" do
    get administrador_url(@administrador)
    assert_response :success
  end

  test "should get edit" do
    get edit_administrador_url(@administrador)
    assert_response :success
  end

  test "should update administrador" do
    patch administrador_url(@administrador), params: { administrador: { dni: @administrador.dni, numero_telefono: @administrador.numero_telefono, primer_apellido: @administrador.primer_apellido, primer_nombre: @administrador.primer_nombre, segundo_apellido: @administrador.segundo_apellido, segundo_nombre: @administrador.segundo_nombre } }
    assert_redirected_to administrador_url(@administrador)
  end

  test "should destroy administrador" do
    assert_difference("Administrador.count", -1) do
      delete administrador_url(@administrador)
    end

    assert_redirected_to administradors_url
  end
end

require "test_helper"

class DocentesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @docente = docentes(:docente_1)
  end

  test "should get index" do
    get docentes_url
    assert_response :success
  end

  test "should get new" do
    get new_docente_url
    assert_response :success
  end

  test "should create docente" do
    assert_difference("Docente.count") do
      post docentes_url, params: { docente: { codigo_docente: @docente.codigo_docente, dni: @docente.dni, numero_telefono: @docente.numero_telefono, primer_apellido: @docente.primer_apellido, primer_nombre: @docente.primer_nombre, segundo_apellido: @docente.segundo_apellido, segundo_nombre: @docente.segundo_nombre, titulo: @docente.titulo } }
    end

    assert_redirected_to docente_url(Docente.last)
  end

  test "should show docente" do
    get docente_url(@docente)
    assert_response :success
  end

  test "should get edit" do
    get edit_docente_url(@docente)
    assert_response :success
  end

  test "should update docente" do
    patch docente_url(@docente), params: { docente: { codigo_docente: @docente.codigo_docente, dni: @docente.dni, numero_telefono: @docente.numero_telefono, primer_apellido: @docente.primer_apellido, primer_nombre: @docente.primer_nombre, segundo_apellido: @docente.segundo_apellido, segundo_nombre: @docente.segundo_nombre, titulo: @docente.titulo } }
    assert_redirected_to docente_url(@docente)
  end

  test "should destroy docente" do
    assert_difference("Docente.count", -1) do
      delete docente_url(@docente)
    end

    assert_redirected_to docentes_url
  end
end

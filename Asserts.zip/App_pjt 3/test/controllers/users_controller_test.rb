# test/controllers/users_controller_test.rb

require 'test_helper'

class UsersControllerTest < ActionController::TestCase
  include Devise::Test::ControllerHelpers

  setup do
    @docente = docentes(:docente_1)
    @estudiante = estudiantes(:estudiante_1)
  end

  test "should get new_associated_user" do
    get :new_associated_user, params: { docente_id: @docente.id }
    assert_response :success
    assert_not_nil assigns(:docente)
    assert_not_nil assigns(:new_user)
  end

  test "should create associated user for docente" do
    assert_difference('User.count') do
      post :create_associated_user, params: { user: { email: "test@example.com", password: "password", password_confirmation: "password", docente_id: @docente.id } }
    end
    assert_redirected_to root_path
    assert_equal "Usuario creado exitosamente", flash[:notice]
  end

  test "should get new_associated_user_estudiante" do
    get :new_associated_user_estudiante, params: { estudiante_id: @estudiante.id }
    assert_response :success
    assert_not_nil assigns(:estudiante)
    assert_not_nil assigns(:new_user)
  end

  test "should create associated user for estudiante" do
    assert_difference('User.count') do
      post :create_associated_user_estudiante, params: { user: { email: "test@example.com", password: "password", password_confirmation: "password", estudiante_id: @estudiante.id } }
    end
    assert_redirected_to root_path
    assert_equal "Usuario creado exitosamente", flash[:notice]
  end
end

require 'test_helper'

class MainControllerTest < ActionController::TestCase
  include Devise::Test::ControllerHelpers

  test "debería redirigir a la página de inicio de sesión si el usuario no está autenticado" do
    get :home
    assert_response :redirect
    assert_redirected_to new_user_session_path
  end

  test "debería obtener la página de inicio cuando el usuario está autenticado" do
    sign_in users(:docente_1)
    get :home
    assert_response :success
    assert_template :home
  end
end

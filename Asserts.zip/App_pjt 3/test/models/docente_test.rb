require "test_helper"

class DocenteTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

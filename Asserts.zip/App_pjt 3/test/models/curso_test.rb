require "test_helper"

class CursoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

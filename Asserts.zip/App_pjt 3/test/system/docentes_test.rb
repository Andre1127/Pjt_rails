require "application_system_test_case"

class DocentesTest < ApplicationSystemTestCase
  setup do
    @docente = docentes(:one)
  end

  test "visiting the index" do
    visit docentes_url
    assert_selector "h1", text: "Docentes"
  end

  test "should create docente" do
    visit docentes_url
    click_on "New docente"

    fill_in "Codigo docente", with: @docente.codigo_docente
    fill_in "Dni", with: @docente.dni
    fill_in "Numero telefono", with: @docente.numero_telefono
    fill_in "Primer apellido", with: @docente.primer_apellido
    fill_in "Primer nombre", with: @docente.primer_nombre
    fill_in "Segundo apellido", with: @docente.segundo_apellido
    fill_in "Segundo nombre", with: @docente.segundo_nombre
    fill_in "Titulo", with: @docente.titulo
    click_on "Create Docente"

    assert_text "Docente was successfully created"
    click_on "Back"
  end

  test "should update Docente" do
    visit docente_url(@docente)
    click_on "Edit this docente", match: :first

    fill_in "Codigo docente", with: @docente.codigo_docente
    fill_in "Dni", with: @docente.dni
    fill_in "Numero telefono", with: @docente.numero_telefono
    fill_in "Primer apellido", with: @docente.primer_apellido
    fill_in "Primer nombre", with: @docente.primer_nombre
    fill_in "Segundo apellido", with: @docente.segundo_apellido
    fill_in "Segundo nombre", with: @docente.segundo_nombre
    fill_in "Titulo", with: @docente.titulo
    click_on "Update Docente"

    assert_text "Docente was successfully updated"
    click_on "Back"
  end

  test "should destroy Docente" do
    visit docente_url(@docente)
    click_on "Destroy this docente", match: :first

    assert_text "Docente was successfully destroyed"
  end
end

class Aula < ApplicationRecord
end

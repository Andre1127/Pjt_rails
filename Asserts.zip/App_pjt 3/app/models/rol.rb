class Rol < ApplicationRecord
  has_many :users
end

class Facultad < ApplicationRecord
  has_many :estudiantes
end

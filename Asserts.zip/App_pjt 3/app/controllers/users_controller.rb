class UsersController < ApplicationController
  def new_associated_user
    @docente = Docente.find(params[:docente_id])
    @new_user = @docente.build_user
  end

  def create_associated_user
    @docente = Docente.find(params[:user][:docente_id])
    @new_user = @docente.build_user(user_params)
    if @new_user.save
      redirect_to root_path, notice: "Usuario creado exitosamente"
    else
      render :new_associated_user
    end
  end

  def new_associated_user_estudiante
    @estudiante = Estudiante.find(params[:estudiante_id])
    @new_user = @estudiante.build_user
  end

  def create_associated_user_estudiante
    @estudiante = Estudiante.find(params[:user][:estudiante_id])
    @new_user = @estudiante.build_user(user_params)
    if @new_user.save
      redirect_to root_path, notice: "Usuario creado exitosamente"
    else
      render :new_associated_user_estudiante
    end
  end

  private

  def user_params
    params.require(:user).permit(:email, :password, :password_confirmation, :rol_id, :docente_id, :estudiante_id)
  end
end

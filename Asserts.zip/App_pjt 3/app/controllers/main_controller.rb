class MainController < ApplicationController
  before_action :authenticate_user!
  def home
    @docente = Docente.find_by(id: params[:docente_id])
    @estudiante = Estudiante.find_by(id: params[:estudiante_id])
    @docentes = Docente.all
    @estudiantes = Estudiante.all
    @cursos = Curso.all
  end
end

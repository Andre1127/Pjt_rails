class CreateJoinTableUsersCursos < ActiveRecord::Migration[7.0]
  def change
    create_join_table :users, :cursos do |t|
      # puedes añadir columnas adicionales aquí si lo necesitas
      # t.integer :user_id
      # t.integer :curso_id
      t.index [:user_id, :curso_id]
      t.index [:curso_id, :user_id]
    end
  end
end

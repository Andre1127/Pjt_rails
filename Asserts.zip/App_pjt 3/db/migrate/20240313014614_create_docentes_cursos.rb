class CreateDocentesCursos < ActiveRecord::Migration[7.0]
  def change
    create_table :docentes_cursos, id: false do |t|
      t.references :docente, null: false, foreign_key: true
      t.references :curso, null: false, foreign_key: true
    end

    # Añade un índice único para evitar duplicados
    add_index :docentes_cursos, [:docente_id, :curso_id], unique: true
  end
end

class CreateCursosEstudiantesJoinTable < ActiveRecord::Migration[7.0]
  def change
    create_table :cursos_estudiantes, id: false do |t|
      t.belongs_to :curso
      t.belongs_to :estudiante
    end
  end
end

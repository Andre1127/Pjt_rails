# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[7.0].define(version: 2024_03_13_164357) do
  create_table "administradors", force: :cascade do |t|
    t.string "primer_nombre"
    t.string "segundo_nombre"
    t.string "primer_apellido"
    t.string "segundo_apellido"
    t.string "dni"
    t.string "numero_telefono"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "aulas", force: :cascade do |t|
    t.string "nombre"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "cursos", force: :cascade do |t|
    t.string "nombre"
    t.string "codigo_curso"
    t.integer "creditos"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "cursos_aulas", id: false, force: :cascade do |t|
    t.integer "curso_id"
    t.integer "aula_id"
    t.index ["aula_id"], name: "index_cursos_aulas_on_aula_id"
    t.index ["curso_id"], name: "index_cursos_aulas_on_curso_id"
  end

  create_table "cursos_docentes", id: false, force: :cascade do |t|
    t.integer "curso_id"
    t.integer "docente_id"
    t.index ["curso_id"], name: "index_cursos_docentes_on_curso_id"
    t.index ["docente_id"], name: "index_cursos_docentes_on_docente_id"
  end

  create_table "cursos_estudiantes", id: false, force: :cascade do |t|
    t.integer "curso_id"
    t.integer "estudiante_id"
    t.index ["curso_id"], name: "index_cursos_estudiantes_on_curso_id"
    t.index ["estudiante_id"], name: "index_cursos_estudiantes_on_estudiante_id"
  end

  create_table "cursos_users", id: false, force: :cascade do |t|
    t.integer "user_id", null: false
    t.integer "curso_id", null: false
    t.index ["curso_id", "user_id"], name: "index_cursos_users_on_curso_id_and_user_id"
    t.index ["user_id", "curso_id"], name: "index_cursos_users_on_user_id_and_curso_id"
  end

  create_table "docentes", force: :cascade do |t|
    t.string "primer_nombre"
    t.string "segundo_nombre"
    t.string "primer_apellido"
    t.string "segundo_apellido"
    t.string "dni"
    t.string "codigo_docente"
    t.string "numero_telefono"
    t.string "titulo"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "user_id"
    t.index ["user_id"], name: "index_docentes_on_user_id"
  end

  create_table "docentes_cursos", id: false, force: :cascade do |t|
    t.integer "docente_id", null: false
    t.integer "curso_id", null: false
    t.index ["curso_id"], name: "index_docentes_cursos_on_curso_id"
    t.index ["docente_id", "curso_id"], name: "index_docentes_cursos_on_docente_id_and_curso_id", unique: true
    t.index ["docente_id"], name: "index_docentes_cursos_on_docente_id"
  end

  create_table "estudiantes", force: :cascade do |t|
    t.string "primer_nombre"
    t.string "segundo_nombre"
    t.string "primer_apellido"
    t.string "segundo_apellido"
    t.string "dni"
    t.string "codigo_alumno"
    t.string "numero_telefono"
    t.boolean "estado"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "facultad_id", null: false
    t.integer "user_id"
    t.index ["facultad_id"], name: "index_estudiantes_on_facultad_id"
    t.index ["user_id"], name: "index_estudiantes_on_user_id"
  end

  create_table "estudiantes_cursos", id: false, force: :cascade do |t|
    t.integer "estudiante_id", null: false
    t.integer "curso_id", null: false
    t.index ["curso_id"], name: "index_estudiantes_cursos_on_curso_id"
    t.index ["estudiante_id", "curso_id"], name: "index_estudiantes_cursos_on_estudiante_id_and_curso_id", unique: true
    t.index ["estudiante_id"], name: "index_estudiantes_cursos_on_estudiante_id"
  end

  create_table "facultads", force: :cascade do |t|
    t.string "nombre"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "rols", force: :cascade do |t|
    t.string "nombre"
    t.string "descripcion"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "users", force: :cascade do |t|
    t.string "email", default: "", null: false
    t.string "encrypted_password", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "rol_id", null: false
    t.integer "administrador_id"
    t.integer "docente_id"
    t.integer "estudiante_id"
    t.index ["administrador_id"], name: "index_users_on_administrador_id"
    t.index ["docente_id"], name: "index_users_on_docente_id"
    t.index ["email"], name: "index_users_on_email", unique: true
    t.index ["estudiante_id"], name: "index_users_on_estudiante_id"
    t.index ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true
    t.index ["rol_id"], name: "index_users_on_rol_id"
  end

  add_foreign_key "docentes", "users"
  add_foreign_key "docentes_cursos", "cursos"
  add_foreign_key "docentes_cursos", "docentes"
  add_foreign_key "estudiantes", "facultads"
  add_foreign_key "estudiantes", "users"
  add_foreign_key "estudiantes_cursos", "cursos"
  add_foreign_key "estudiantes_cursos", "estudiantes"
  add_foreign_key "users", "administradors"
  add_foreign_key "users", "docentes"
  add_foreign_key "users", "estudiantes"
  add_foreign_key "users", "rols"
end

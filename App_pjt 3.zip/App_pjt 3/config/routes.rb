Rails.application.routes.draw do
  root 'main#home'
  get '/cursos/inscripcion', to: 'cursos#inscripcion', as: 'inscripcion_cursos'
  resources :cursos do
    post 'enroll', on: :collection
  end
  devise_for :users, skip: [:registrations]
  devise_scope :user do
    get '/users/sign_up', to: 'devise/registrations#new', as: 'new_user_registration'
    post '/users', to: 'devise/registrations#create', as: 'user_registration'
  end

  get 'cursos_inscritos', to: 'inscripciones#cursos_inscritos', as: 'cursos_inscritos'

  get '/users/new_associated_user', to: 'users#new_associated_user', as: 'new_associated_user'
  post '/users/create_associated_user', to: 'users#create_associated_user', as: 'create_associated_user'
  get '/users/new_associated_user_estudiante', to: 'users#new_associated_user_estudiante', as: 'new_associated_user_estudiante'
  post '/users/create_associated_user_estudiante', to: 'users#create_associated_user_estudiante', as: 'create_associated_user_estudiante'

  resources :aulas
  resources :facultads
  resources :cursos
  resources :administradors
  resources :docentes
  resources :estudiantes
  resources :rols
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
end

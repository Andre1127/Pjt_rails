class User < ApplicationRecord
  belongs_to :rol
  belongs_to :administrador, optional: true
  belongs_to :docente, optional: true
  validates :docente_id, uniqueness: true, allow_nil: true # Permitir que docente_id sea nil para los usuarios no asociados a docentes
  belongs_to :estudiante, optional: true
  validates :estudiante_id, uniqueness: true, allow_nil: true # Permitir que estudiante_id sea nil para los usuarios no asociados a estudiantes
  has_and_belongs_to_many :cursos

  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable

  after_initialize :assign_default_rol, if: :new_record?

  validate :validate_at_least_one_docente_or_estudiante_exists

  # Asigna el rol predeterminado al usuario
  def assign_default_rol
    self.rol ||= Rol.find_by(nombre: 'estudiante')
  end

  def admin?
    rol_id == 1
  end

  def docente?
    rol_id == 2
  end

  def estudiante?
    rol_id == 3
  end

  private

  # Valida que al menos exista un docente o un estudiante asociado al usuario
  def validate_at_least_one_docente_or_estudiante_exists
    unless docente_id.present? || estudiante_id.present?
      errors.add(:base, "Debe asociarse al menos a un docente o a un estudiante")
    end
  end
end

class Facultad < ApplicationRecord
end

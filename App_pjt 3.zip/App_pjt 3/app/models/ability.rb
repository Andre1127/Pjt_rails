class Ability
  include CanCan::Ability

  def initialize(user)
    user ||= User.new  # Si el usuario no está autenticado

    if user.rol_id == 1  # Supongamos que el ID del rol de administrador es 1
      can :manage, :all  # Un administrador puede realizar cualquier acción en cualquier modelo
    elsif user.rol_id == 2  # Supongamos que el ID del rol de docente es 2
      can :manage, Curso  # Un docente puede gestionar los cursos

    elsif user.rol_id == 3  # Supongamos que el ID del rol de estudiante es 3
      can [:read, :update], Estudiante, id: user.id
      can :enroll, Curso
      can :read, Curso  # Un estudiante puede ver la lista de cursos
    end
    can :register_courses, Estudiante if user.rol_id == 1
  end
end

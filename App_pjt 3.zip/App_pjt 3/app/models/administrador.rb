class Administrador < ApplicationRecord
end

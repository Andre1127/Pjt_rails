class Curso < ApplicationRecord
  has_and_belongs_to_many :estudiantes
  has_and_belongs_to_many :docentes
  has_and_belongs_to_many :users
end

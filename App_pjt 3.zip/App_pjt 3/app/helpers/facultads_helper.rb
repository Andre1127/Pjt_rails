module FacultadsHelper
end

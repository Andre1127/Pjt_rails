class InscripcionesController < ApplicationController
  before_action :authenticate_user! # Asegura que el usuario esté autenticado antes de acceder a esta funcionalidad

  def cursos_inscritos
    @user = current_user
    @cursos = @user.cursos.includes(:users)
  end
end

class CursosController < ApplicationController
  before_action :set_curso, only: %i[ show edit update destroy ]

  # GET /cursos or /cursos.json
  def index
    @cursos = Curso.all
  end

  # GET /cursos/1 or /cursos/1.json
  def show
  end

  # GET /cursos/new
  def new
    @curso = Curso.new
  end

  # GET /cursos/1/edit
  def edit
  end

  # POST /cursos or /cursos.json
  def create
    @curso = Curso.new(curso_params)

    respond_to do |format|
      if @curso.save
        format.html { redirect_to curso_url(@curso), notice: "Curso was successfully created." }
        format.json { render :show, status: :created, location: @curso }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @curso.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /cursos/1 or /cursos/1.json
  def update
    respond_to do |format|
      if @curso.update(curso_params)
        format.html { redirect_to curso_url(@curso), notice: "Curso was successfully updated." }
        format.json { render :show, status: :ok, location: @curso }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @curso.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /cursos/1 or /cursos/1.json
  def destroy
    @curso.destroy

    respond_to do |format|
      format.html { redirect_to cursos_url, notice: "Curso was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  def inscripcion
    @cursos = Curso.all
  end

  def enroll
    puts "Params received: #{params.inspect}"
    curso_ids = params[:curso_ids]
    current_user.cursos << Curso.find(curso_ids) if curso_ids.present?
    redirect_to inscripcion_cursos_path, notice: "Te has inscrito en los cursos exitosamente."
  end


  private
    # Use callbacks to share common setup or constraints between actions.
    def set_curso
      if params[:id] == 'enroll'
        # Aquí deberías escribir la lógica para encontrar el curso adecuado cuando se pasa 'enroll' como ID
        # Por ejemplo:
        @curso = Curso.find_by(nombre: 'Enroll')
        # O alguna otra lógica que te permita encontrar el curso correcto cuando se pasa 'enroll'
        unless @curso
          # Si no se encuentra un curso con el nombre 'Enroll', puedes manejarlo según sea necesario.
          # Por ejemplo, podrías lanzar una excepción o redirigir a otra página.
          redirect_to root_path, alert: 'No se encontró un curso de inscripción.'
        end
      else
        @curso = Curso.find(params[:id])
      end
    end


    # Only allow a list of trusted parameters through.
    def curso_params
      params.require(:curso).permit(:nombre, :codigo_curso, :creditos)
    end
end

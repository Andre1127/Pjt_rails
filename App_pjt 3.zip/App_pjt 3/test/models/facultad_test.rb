require "test_helper"

class FacultadTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

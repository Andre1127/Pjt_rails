class CreateEstudiantesCursos < ActiveRecord::Migration[7.0]
  def change
    create_table :estudiantes_cursos, id: false do |t|
      t.references :estudiante, null: false, foreign_key: true
      t.references :curso, null: false, foreign_key: true
    end

    # Añade un índice único para evitar duplicados
    add_index :estudiantes_cursos, [:estudiante_id, :curso_id], unique: true
  end
end

class CreateCursosDocentesJoinTable < ActiveRecord::Migration[7.0]
  def change
    create_table :cursos_docentes, id: false do |t|
      t.belongs_to :curso
      t.belongs_to :docente
    end
  end
end

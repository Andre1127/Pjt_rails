class CreateDocentes < ActiveRecord::Migration[7.0]
  def change
    create_table :docentes do |t|
      t.string :primer_nombre
      t.string :segundo_nombre
      t.string :primer_apellido
      t.string :segundo_apellido
      t.string :dni
      t.string :codigo_docente
      t.string :numero_telefono
      t.string :titulo

      t.timestamps
    end
  end
end
